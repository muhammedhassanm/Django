# DjangoWithCNN
This is a Django app I created to host my Convolutional Neural Network for facial expression recognition.

Link:
http://lamuong.com/myapp/

I used Amazon Web Services to host the app.
